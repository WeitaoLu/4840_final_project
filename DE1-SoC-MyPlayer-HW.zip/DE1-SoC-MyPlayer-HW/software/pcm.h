#ifndef _pcm_h_
#define _pcm_h_
int play_PCM(const char *filename);
#endif